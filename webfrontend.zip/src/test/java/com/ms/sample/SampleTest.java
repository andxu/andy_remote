package com.ms.sample;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SampleTest {

    @Test
    public void firstTest() throws Exception {
    	   assertEquals("10 x 0 must be 0", 0, 10 * 0);
    }


}
